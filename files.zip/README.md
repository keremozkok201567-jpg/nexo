# NEXO

Kurulum gerektirmeyen, koyu temalı mesajlaşma uygulaması: mesaj, fotoğraf, sesli ve görüntülü arama.

## Yayınlama

1. `index.html` dosyasını GitHub'da bir depoya yükle.
2. Settings > Pages bölümünden `main` dalını seç.
3. `https://KULLANICI_ADIN.github.io/depo-adi/` adresini arkadaşlarına gönder.

Başka bir ayar yok. Herkes ad ve kullanıcı adı seçip başlar, sonra arkadaşının kullanıcı adını yazarak onu ekler.

## Nasıl çalışır

Mesajlar ve aramalar cihazdan cihaza (WebRTC) gider. Ücretsiz PeerJS aracı sunucusu yalnızca iki cihazın birbirini bulmasını sağlar, mesajların içeriğini görmez ve saklamaz. Sohbet geçmişi sadece kendi cihazının tarayıcısında durur.

## Sınırlar

- İki kişi de çevrimiçi olmalı. Karşı taraf çevrimdışıyken yazdığın mesaj "bekliyor" kalır, ikiniz de uygulamayı açık tuttuğunuzda iletilir.
- Parola yok. Kullanıcı adını sahibi çevrimiçi değilken bir başkası alabilir.
- Tarayıcı verisini silersen sohbet geçmişi gider.
- Bazı mobil ve kurumsal ağlarda doğrudan bağlantı kurulamayabilir.
- Uygulama kapalıyken bildirim veya arama gelmez.

`nexo-sunucu.html`, bu sınırları kaldıran sunuculu sürümdür (hesap, parola, çevrimdışı mesaj teslimi). Kullanmak için Firebase kurulumu gerekir ve ayrı bir adım listesi ister.
